from django.contrib import admin
from bticket.models import Ticket,Bus
class TicketAdmin(admin.ModelAdmin):
    list_display=['full_name','date','id','From','To','price']
class BusAdmin(admin.ModelAdmin):
    list_display=['Bus_no','From1','To1','Price']
admin.site.register(Ticket,TicketAdmin)
admin.site.register(Bus,BusAdmin)
